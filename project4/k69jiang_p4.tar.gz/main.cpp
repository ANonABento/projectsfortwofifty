#include "Graph.h"
#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <cmath> // For floor/ceil checks if needed

using namespace std;

// Helper to print weight cleanly (Integer if whole number, 1 decimal otherwise)
void printWeight(double weight) {
    // Check if weight is effectively an integer (handling small float errors)
    if (std::abs(weight - std::round(weight)) < 0.0001) {
        cout << (long long)std::round(weight) << endl;
    } else {
        cout << fixed << setprecision(1) << weight << endl;
    }
}

int main() {
    // Optimization: fast I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    Graph graph;
    string command;
    
    while(cin >> command) {
        
        if(command == "LOAD") {
            string filename, type;
            cin >> filename >> type;
            
            if(type == "entities") {
                graph.loadEntities(filename);
            } else if(type == "relationships") {
                graph.loadRelationships(filename);
            }
            // PDF says LOAD generally succeeds if format is correct
            cout << "success" << endl;
            
        } else if(command == "ENTITY") {
            string id, name, type;
            cin >> id >> name >> type;
            
            graph.insertEntity(id, name, type);
            cout << "success" << endl;
            
        } else if(command == "RELATIONSHIP") {
            string sourceId, label, destId;
            double weight;
            cin >> sourceId >> label >> destId >> weight;
            
            bool result = graph.insertRelationship(sourceId, label, destId, weight);
            if(result) {
                cout << "success" << endl;
            } else {
                cout << "failure" << endl;
            }
            
        } else if(command == "PRINT") {
            string id;
            cin >> id;
            
            try {
                // Let the Graph class handle validation!
                // If ID is illegal, printAdjacent throws illegal_exception
                // If ID not found, it returns empty or throws (depending on your Graph.cpp implementation)
                
                // Based on previous Graph.cpp, printAdjacent throws for illegal chars
                // and returns empty or throws for not found. 
                // We need to ensure we catch the specific "not in graph" case vs "illegal".
                
                // NOTE: In the previous Graph.cpp I provided, printAdjacent throws illegal_exception
                // if ID is invalid. It returns empty vector if node not found? 
                // Actually, the PDF says PRINT fails if node not in graph.
                // So we check if node exists first, but AFTER validation.
                
                // To keep main clean, we rely on Graph methods.
                // If you use the Graph.cpp I provided previously, you need to make sure
                // printAdjacent throws/returns correctly.
                
                // Here is the robust logic:
                vector<string> adjacent = graph.printAdjacent(id); // Will throw if illegal
                
                // If we get here, ID is valid format.
                // Check if the node actually existed (Graph.cpp should handle this check)
                // If graph.printAdjacent returns empty vector for "node not found", we check:
                if (graph.getNode(id) == nullptr) {
                     cout << "failure" << endl;
                } else {
                    for(int i = 0; i < adjacent.size(); i++) {
                        if(i > 0) cout << " ";
                        cout << adjacent[i];
                    }
                    cout << endl;
                }
            } catch(illegal_exception& e) {
                cout << "illegal argument" << endl;
            }
            
        } else if(command == "DELETE") {
            string id;
            cin >> id;
            
            try {
                bool result = graph.deleteNode(id); // Will throw if illegal
                if(result) {
                    cout << "success" << endl;
                } else {
                    cout << "failure" << endl;
                }
            } catch(illegal_exception& e) {
                cout << "illegal argument" << endl;
            }
            
        } else if(command == "PATH") {
            string id1, id2;
            cin >> id1 >> id2;
            
            try {
                double totalWeight = 0;
                // findPath checks validity of both IDs and throws illegal_exception if needed
                vector<string> path = graph.findPath(id1, id2, totalWeight);
                
                if(path.size() == 0) {
                    cout << "failure" << endl;
                } else {
                    for(int i = 0; i < path.size(); i++) {
                        cout << path[i] << " ";
                    }
                    printWeight(totalWeight);
                }
            } catch(illegal_exception& e) {
                cout << "illegal argument" << endl;
            }
            
        } else if(command == "HIGHEST") {
            double totalWeight = 0;
            vector<string> path = graph.findHighest(totalWeight);
            
            if(path.size() == 0) {
                cout << "failure" << endl;
            } else {
                cout << path[0] << " " << path[path.size() - 1] << " ";
                printWeight(totalWeight);
            }
            
        } else if(command == "FINDALL") {
            string fieldType, fieldString;
            cin >> fieldType >> fieldString;
            
            vector<string> results = graph.findAll(fieldType, fieldString);
            
            if(results.size() == 0) {
                cout << "failure" << endl;
            } else {
                for(int i = 0; i < results.size(); i++) {
                    if(i > 0) cout << " ";
                    cout << results[i];
                }
                cout << endl;
            }
            
        } else if(command == "EXIT") {
            break;
        }
    }
    
    return 0;
}